function Area(radius) {
  var Result = 0;
  Result = 3.14 * radius * radius;
  return Result;
}
var Ans = 0;
Ans = Area(5);
console.log("Area is : " + Ans);
